import json
import math
import random
import socket
import time

IP = '127.0.0.1'
PORT = 5700
RATE_HZ = 50

ACC_FREQ = (0.4, 0.7, 1.1)
ACC_AMP = (1.0, 1.0, 1.0)
BUTTON_TOGGLE_PROB = 0.02


def main():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    period = 1.0 / RATE_HZ
    button = 0
    last_button = 0
    t0 = time.time()

    print(f'sending DIPPID packets to {IP}:{PORT} at {RATE_HZ} Hz')

    while True:
        t = time.time() - t0

        accel = {
            'x': round(ACC_AMP[0] * math.sin(2 * math.pi * ACC_FREQ[0] * t), 4),
            'y': round(ACC_AMP[1] * math.sin(2 * math.pi * ACC_FREQ[1] * t), 4),
            'z': round(ACC_AMP[2] * math.sin(2 * math.pi * ACC_FREQ[2] * t), 4),
        }
        sock.sendto(json.dumps({'accelerometer': accel}).encode(), (IP, PORT))

        if random.random() < BUTTON_TOGGLE_PROB:
            button = 1 - button
        if button != last_button:
            sock.sendto(json.dumps({'button_1': button}).encode(), (IP, PORT))
            last_button = button

        time.sleep(period)


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        pass
