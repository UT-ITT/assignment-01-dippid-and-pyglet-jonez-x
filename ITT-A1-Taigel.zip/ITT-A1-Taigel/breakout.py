import math
import os
import random
import sys

import pyglet
from pyglet import shapes
from pyglet.window import key

from DIPPID import SensorUDP

WINDOW_W = 800
WINDOW_H = 600
PORT = 5700

PADDLE_W = 120
PADDLE_H = 14
PADDLE_Y = 40
PADDLE_SMOOTH = 0.18
TILT_DEAD_ZONE = 0.05
TILT_GAIN = (WINDOW_W - PADDLE_W) / 2

BALL_R = 8
BALL_SPEED = 360
BALL_SPEED_INC = 1.04
MAX_BOUNCE_ANGLE = math.radians(60)

BRICK_ROWS = 5
BRICK_COLS = 10
BRICK_W = 70
BRICK_H = 22
BRICK_TOP = WINDOW_H - 60
BRICK_GAP = 4
BRICK_LEFT = (WINDOW_W - (BRICK_COLS * BRICK_W + (BRICK_COLS - 1) * BRICK_GAP)) // 2

LIVES_START = 3
SCORE_PER_BRICK = 10

ROW_COLORS = [
    (255, 96, 96),
    (255, 168, 96),
    (255, 224, 96),
    (128, 224, 128),
    (96, 168, 255),
]
BG = (18, 22, 32)
PADDLE_COLOR = (240, 240, 240)
BALL_COLOR = (255, 255, 255)
TEXT_COLOR = (220, 220, 220, 255)


class Brick:
    def __init__(self, x, y, color, batch):
        self.x = x
        self.y = y
        self.w = BRICK_W
        self.h = BRICK_H
        self.alive = True
        self.shape = shapes.Rectangle(x, y, BRICK_W, BRICK_H, color, batch=batch)


class Game:
    STATE_READY = 'ready'
    STATE_PLAYING = 'playing'
    STATE_GAME_OVER = 'game_over'
    STATE_WON = 'won'

    def __init__(self):
        self.window = pyglet.window.Window(WINDOW_W, WINDOW_H, 'Breakout (DIPPID)')
        pyglet.gl.glClearColor(BG[0] / 255, BG[1] / 255, BG[2] / 255, 1.0)

        self.batch = pyglet.graphics.Batch()
        self.fg_batch = pyglet.graphics.Batch()

        self.paddle = shapes.Rectangle(
            (WINDOW_W - PADDLE_W) / 2, PADDLE_Y, PADDLE_W, PADDLE_H,
            PADDLE_COLOR, batch=self.fg_batch)
        self.paddle_target_x = self.paddle.x

        self.ball = shapes.Circle(WINDOW_W / 2, PADDLE_Y + PADDLE_H + BALL_R,
                                  BALL_R, color=BALL_COLOR, batch=self.fg_batch)
        self.ball_vx = 0.0
        self.ball_vy = 0.0
        self.ball_speed = BALL_SPEED

        self.bricks = []
        for row in range(BRICK_ROWS):
            for col in range(BRICK_COLS):
                x = BRICK_LEFT + col * (BRICK_W + BRICK_GAP)
                y = BRICK_TOP - row * (BRICK_H + BRICK_GAP)
                self.bricks.append(Brick(x, y, ROW_COLORS[row], self.batch))

        self.score = 0
        self.lives = LIVES_START
        self.state = self.STATE_READY

        self.score_label = pyglet.text.Label(
            '', font_name='Arial', font_size=14, x=20, y=WINDOW_H - 28,
            color=TEXT_COLOR)
        self.lives_label = pyglet.text.Label(
            '', font_name='Arial', font_size=14, x=WINDOW_W - 20, y=WINDOW_H - 28,
            anchor_x='right', color=TEXT_COLOR)
        self.message_label = pyglet.text.Label(
            '', font_name='Arial', font_size=22, x=WINDOW_W / 2, y=WINDOW_H / 2,
            anchor_x='center', anchor_y='center', color=TEXT_COLOR)

        self.sensor = SensorUDP(PORT)
        self.sensor.register_callback('button_1', self._on_button)
        self._button_was_pressed = False

        self.window.event(self.on_draw)
        self.window.event(self.on_key_press)
        pyglet.clock.schedule_interval(self.update, 1 / 120.0)

    def _on_button(self, value):
        try:
            pressed = int(value) == 1
        except (TypeError, ValueError):
            return
        if pressed and not self._button_was_pressed:
            self._handle_action()
        self._button_was_pressed = pressed

    def _handle_action(self):
        if self.state == self.STATE_READY:
            self._launch_ball()
        elif self.state in (self.STATE_GAME_OVER, self.STATE_WON):
            self._reset()

    def _launch_ball(self):
        angle = random.uniform(math.radians(60), math.radians(120))
        self.ball_speed = BALL_SPEED
        self.ball_vx = math.cos(angle) * self.ball_speed
        self.ball_vy = math.sin(angle) * self.ball_speed
        self.state = self.STATE_PLAYING

    def _reset(self):
        for b in self.bricks:
            if not b.alive:
                b.alive = True
                b.shape.opacity = 255
        self.score = 0
        self.lives = LIVES_START
        self._reset_ball_to_paddle()
        self.state = self.STATE_READY

    def _reset_ball_to_paddle(self):
        self.ball.x = self.paddle.x + PADDLE_W / 2
        self.ball.y = PADDLE_Y + PADDLE_H + BALL_R
        self.ball_vx = 0
        self.ball_vy = 0

    def _read_tilt(self):
        if not self.sensor.has_capability('accelerometer'):
            return 0.0
        v = self.sensor.get_value('accelerometer')
        if not isinstance(v, dict):
            return 0.0
        try:
            x = float(v.get('x', 0.0))
        except (TypeError, ValueError):
            return 0.0
        if abs(x) < TILT_DEAD_ZONE:
            return 0.0
        return max(-1.0, min(1.0, x))

    def update(self, dt):
        tilt = self._read_tilt()
        center_x = WINDOW_W / 2 + tilt * TILT_GAIN
        self.paddle_target_x = max(0, min(WINDOW_W - PADDLE_W, center_x - PADDLE_W / 2))
        self.paddle.x += (self.paddle_target_x - self.paddle.x) * PADDLE_SMOOTH

        if self.state == self.STATE_READY:
            self.ball.x = self.paddle.x + PADDLE_W / 2
            self.ball.y = PADDLE_Y + PADDLE_H + BALL_R
            return

        if self.state != self.STATE_PLAYING:
            return

        self.ball.x += self.ball_vx * dt
        self.ball.y += self.ball_vy * dt

        if self.ball.x - BALL_R <= 0 and self.ball_vx < 0:
            self.ball.x = BALL_R
            self.ball_vx = -self.ball_vx
        if self.ball.x + BALL_R >= WINDOW_W and self.ball_vx > 0:
            self.ball.x = WINDOW_W - BALL_R
            self.ball_vx = -self.ball_vx
        if self.ball.y + BALL_R >= WINDOW_H and self.ball_vy > 0:
            self.ball.y = WINDOW_H - BALL_R
            self.ball_vy = -self.ball_vy

        if (self.ball_vy < 0
                and self.paddle.x <= self.ball.x <= self.paddle.x + PADDLE_W
                and PADDLE_Y <= self.ball.y - BALL_R <= PADDLE_Y + PADDLE_H + 4):
            offset = (self.ball.x - (self.paddle.x + PADDLE_W / 2)) / (PADDLE_W / 2)
            offset = max(-1.0, min(1.0, offset))
            angle = offset * MAX_BOUNCE_ANGLE
            self.ball_vx = self.ball_speed * math.sin(angle)
            self.ball_vy = self.ball_speed * math.cos(angle)
            self.ball.y = PADDLE_Y + PADDLE_H + BALL_R

        for brick in self.bricks:
            if not brick.alive:
                continue
            if (brick.x <= self.ball.x <= brick.x + brick.w
                    and brick.y <= self.ball.y <= brick.y + brick.h):
                brick.alive = False
                brick.shape.opacity = 0
                self.score += SCORE_PER_BRICK
                overlap_x = min(self.ball.x - brick.x, brick.x + brick.w - self.ball.x)
                overlap_y = min(self.ball.y - brick.y, brick.y + brick.h - self.ball.y)
                if overlap_x < overlap_y:
                    self.ball_vx = -self.ball_vx
                else:
                    self.ball_vy = -self.ball_vy
                self.ball_speed = min(self.ball_speed * BALL_SPEED_INC, BALL_SPEED * 2.5)
                norm = math.hypot(self.ball_vx, self.ball_vy)
                if norm > 0:
                    self.ball_vx = self.ball_vx / norm * self.ball_speed
                    self.ball_vy = self.ball_vy / norm * self.ball_speed
                break

        if self.ball.y - BALL_R < 0:
            self.lives -= 1
            if self.lives <= 0:
                self.state = self.STATE_GAME_OVER
            else:
                self.state = self.STATE_READY
                self._reset_ball_to_paddle()

        if all(not b.alive for b in self.bricks):
            self.state = self.STATE_WON

    def on_draw(self):
        self.window.clear()
        self.batch.draw()
        self.fg_batch.draw()

        self.score_label.text = f'Score: {self.score}'
        self.lives_label.text = f'Lives: {self.lives}'
        self.score_label.draw()
        self.lives_label.draw()

        if self.state == self.STATE_READY:
            self.message_label.text = 'Tilt to move - press button to launch'
            self.message_label.draw()
        elif self.state == self.STATE_GAME_OVER:
            self.message_label.text = f'Game over - press button to restart  (Score {self.score})'
            self.message_label.draw()
        elif self.state == self.STATE_WON:
            self.message_label.text = f'You won! Final score {self.score} - press button to play again'
            self.message_label.draw()

    def on_key_press(self, symbol, modifiers):
        if symbol == key.Q or symbol == key.ESCAPE:
            self._shutdown()
        if symbol == key.SPACE:
            self._handle_action()

    def _shutdown(self):
        try:
            self.sensor.disconnect()
        except Exception:
            pass
        os._exit(0)


def main():
    Game()
    pyglet.app.run()


if __name__ == '__main__':
    main()
